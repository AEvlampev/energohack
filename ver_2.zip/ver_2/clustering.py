import numpy as np
from sklearn.cluster import MiniBatchKMeans
from sklearn.metrics import silhouette_score
from sklearn.decomposition import PCA

def perform_clustering(X, max_k=7, use_pca=True):
    # Снижение размерности, если признаков много
    if use_pca and X.shape[1] > 15:
        pca = PCA(n_components=0.95, random_state=42)
        X = pca.fit_transform(X)
        print(f"PCA reduced features to {X.shape[1]}")

    best_k = 4
    best_score = -1
    best_model = None

    # Быстрый перебор
    for k in range(4, max_k + 1):
        km = MiniBatchKMeans(
            n_clusters=k, random_state=42, batch_size=2048,
            n_init=3, max_iter=20, reassignment_ratio=0.01
        )
        labels = km.fit_predict(X)
        if len(set(labels)) > 1:
            score = silhouette_score(X, labels, sample_size=10000, n_jobs=-1, random_state=42)
            if score > best_score:
                best_score = score
                best_k = k
                best_model = km

    if best_model is None:
        best_model = MiniBatchKMeans(n_clusters=4, random_state=42, batch_size=2048, n_init=3)
        best_model.fit(X)

    return best_model, best_model.labels_

def profile_clusters(snapshot_with_labels):
    """Средние характеристики кластеров."""
    return snapshot_with_labels.groupby('cluster').agg({
        'debt_amount': 'mean',
        'debt_age': 'mean',
        'avg_payment_3m': 'mean',
        'num_contacts': 'mean',
        'has_phone': 'mean',
        'has_email': 'mean',
        'prev_restriction_notice': 'mean'
    }).round(2)