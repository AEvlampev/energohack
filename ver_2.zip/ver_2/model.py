import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import cross_val_predict, KFold
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

def train_recovery_model(snapshot, feature_cols, target_col='recovery_rate'):
    """
    Обучает RandomForestRegressor для предсказания доли возврата долга.
    Возвращает модель и словарь метрик.
    """
    df = snapshot.dropna(subset=feature_cols + [target_col])
    X = df[feature_cols].fillna(0)
    y = df[target_col]

    model = RandomForestRegressor(
        n_estimators=80, max_depth=10, random_state=42, n_jobs=-1
    )

    cv = KFold(n_splits=3, shuffle=True, random_state=42)
    y_pred = cross_val_predict(model, X, y, cv=cv)

    # Метрики регрессии
    mae = mean_absolute_error(y, y_pred)
    mse = mean_squared_error(y, y_pred)
    rmse = np.sqrt(mse)
    r2 = r2_score(y, y_pred)

    # Бизнес-метрика: доля прогнозов с ошибкой меньше 0.1 (10 процентных пунктов)
    accuracy_10pct = np.mean(np.abs(y - y_pred) < 0.1)

    metrics = {
        'MAE': mae,
        'RMSE': rmse,
        'R2': r2,
        'accuracy_within_10pct': accuracy_10pct  # доля точных прогнозов ±10%
    }

    # Обучаем на всём датасете
    model.fit(X, y)
    return model, metrics

def predict_recovery_rate(model, df, feature_cols):
    """Возвращает Series с прогнозом доли возврата (от 0 до 1)."""
    X = df[feature_cols].fillna(0)
    preds = model.predict(X)
    # Обрезаем до [0, 1], так как регрессия может выходить за границы
    preds = np.clip(preds, 0.0, 1.0)
    return preds