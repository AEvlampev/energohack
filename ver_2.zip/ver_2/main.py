import pandas as pd
import argparse
import json
from pathlib import Path
import config as cfg
from preprocessing import load_all_data, build_monthly_snapshot
from feature_engineering import prepare_clustering_features, add_cluster_labels
from clustering import perform_clustering, profile_clusters
from model import train_recovery_model
from optimizer import greedy_optimize
from explainer import generate_explanations
import warnings
warnings.filterwarnings('ignore')

def main(target_date_str):
    target_month = pd.to_datetime(target_date_str)
    output_dir = Path('output')
    output_dir.mkdir(exist_ok=True)

    print("Загрузка данных...")
    data = load_all_data()

    print("Формирование снимка на", target_date_str)
    snapshot = build_monthly_snapshot(data, target_month)
    snapshot = snapshot[snapshot['debt_amount'] > 0].copy()
    print(f"Найдено должников: {len(snapshot)}")

    print("Подготовка признаков для кластеризации...")
    X, feat_names, preprocessor = prepare_clustering_features(snapshot)

    print("Кластеризация...")
    if len(snapshot) < 4:
        snapshot['cluster'] = 0
    else:
        model, labels = perform_clustering(X)
        snapshot = add_cluster_labels(snapshot, labels)
        print(f"Выделено кластеров: {len(set(labels))}")

    print("Профили кластеров:")
    profiles = profile_clusters(snapshot)
    print(profiles)

    # ----- Обучение регрессионной модели (доля возврата) -----
    print("\nОбучение модели прогноза доли возврата долга...")
    feature_cols = [
        'debt_amount', 'debt_age', 'num_contacts',
        'has_phone', 'has_email', 'has_benefits', 'gasification',
        'mkd', 'dormitory', 'trend_debt',
        'prev_restriction_notice', 'prev_restriction', 'prev_court_order',
        'has_info_measures', 'has_restriction_measures'
    ]
    available_feats = [f for f in feature_cols if f in snapshot.columns]

    if 'recovery_rate' not in snapshot.columns:
        # fallback, если вдруг не создалась
        snapshot['recovery_rate'] = 0.0

    model, metrics = train_recovery_model(snapshot, available_feats, target_col='recovery_rate')
    print("Метрики модели (кросс-валидация):")
    for k, v in metrics.items():
        print(f"  {k}: {v:.4f}")
    with open(output_dir / 'metrics.json', 'w') as f:
        json.dump(metrics, f, indent=2)

    effectiveness = {}  # не используется

    print("\nОптимизация назначений...")
    recommendations, rec_df = greedy_optimize(
        snapshot, effectiveness, cfg.MONTHLY_LIMITS, cfg.MEASURE_CRITERIA,
        model=model, feature_cols=available_feats
    )

    print("Генерация обоснований...")
    explanations = generate_explanations(snapshot, recommendations, profiles, rec_df)

    # Объединяем итоговый результат
    final = explanations.merge(
        rec_df[['account_id', 'measures', 'predicted_rate', 'expected_recovery']],
        on='account_id', how='left'
    )
    output_file = output_dir / f'recommendations_{target_date_str}.csv'
    final.to_csv(output_file, index=False, encoding='utf-8-sig')
    print(f"Готово. Результат сохранён в {output_file}")

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--date', required=True, help='Целевой месяц в формате YYYY-MM-01')
    args = parser.parse_args()
    main(args.date)